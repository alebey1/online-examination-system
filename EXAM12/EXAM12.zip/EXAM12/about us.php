  Today  Online Examination System has become a fast growing examination method because of its speed and accuracy.
It is also needed less manpower to execute the examination.
 Almost all organizations now-a-days, are conducting their objective exams by online examination system, 
 it saves students time in examinations. 
 Organizations can also easily check the performance of the student that they give in an examination. 
 As a result of this, organizations are releasing results in less time. 
 It also helps the environment by saving paper. 
 According to today’s requirement, online examination project in php is very useful to learn it. 
 What is an online examination system? In an online examination system examine get their user id and password with his/her admit card. 
 This id is already saved in the examination server. 
 When examine login to the server he/she get his/her profile already register.
 All answers given by examine are saved into the server with his/her profile information.
 Php is a web base language so we can create an online examination system in PHP. 
 Administrator of Online Examination has multiple features such as Add, Delete, Edit,manage Users and Question.
Online examination system features Login system must be present and secured by password.
Admin Panel Project objective: Online examination system is a non removable examination pattern of today's life. 
We need more time saving and more accurate examination system as the number of applicants is increasing day by day.
For all Software Engineering students, it is very important to have some basic understanding about the online examination system. 
Brief overview of the technology:Front end:HTML,CSS,JavaScript  
HTML: HTML is used to create and save web document. E.g. Notepad/Notepad++ 
CSS : (Cascading Style Sheets) Create attractive Layout 
JavaScript: it is a programming language, commonly use with web browsers. 
Back end: PHP, MySQL  
PHP: Hypertext Preprocessor (PHP) is a technology that allows software developers to create 
dynamically generated web pages, in HTML, XML, or other document types, as per client request.
PHP is open source software. MySQL: MySql is a database, widely used for accessing querying, updating, and managing data in databases. 
